﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp2
{
    public partial class Login : Form
    {
        public Login()
        {
            InitializeComponent();
        }

        

        private void btnLogin_Click_1(object sender, EventArgs e)
        {
            string user, pass;
            user = textUser.Text;
            pass = textPass.Text;
            if (user == "U123" && pass == "Pass123")
            {
                MessageBox.Show("Login Successful");
                Form1 frm1 = new Form1(); // When the lofin is finished the user will be redirected to form 1 

                frm1.Show();
            }
            else
            {
                MessageBox.Show("Please enter valid username or password");
            }
        }

        private void textUser_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
